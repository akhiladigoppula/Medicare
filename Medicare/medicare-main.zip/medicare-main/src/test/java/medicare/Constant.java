package medicare;

public class Constant {

	public static final String DRIVER_PATH = "/home/ubuntu/geckodriver-v0.29.1-linux64/geckodriver";

	public static final String BASE_PATH = "http://localhost:8081/Medicare/";
}
